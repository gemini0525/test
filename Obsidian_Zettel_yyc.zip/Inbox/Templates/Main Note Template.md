<%*
// Auto-generate filename: YYYY-MM-DD.md
await tp.file.rename(tp.date.now("YYYYMMDDHHmm"))
-%>
# 标题





 - Metadata
	- source: 
	- domain: #null  
	- object: 
	- function: 
	- status: 